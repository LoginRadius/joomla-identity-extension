DROP TABLE IF EXISTS `#__loginradius_settings`;
