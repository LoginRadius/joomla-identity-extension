DROP TABLE IF EXISTS `#__loginradius_settings`;
DROP TABLE IF EXISTS `#__loginradius_advanced_settings`;
DROP TABLE IF EXISTS `#__loginradius_log`;


