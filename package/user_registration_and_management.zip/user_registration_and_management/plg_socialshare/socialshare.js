var ossscript;
if (window.ossscript != true) {
    ossscript = true;
    document.write('<script type="text/javascript" src="//share.lrcontent.com/prod/v2/js/opensocialshare.js"></script>');
    document.write('<script type="text/javascript" src="//share.lrcontent.com/prod/v2/js/opensocialsharedefaulttheme.js"></script>');
    document.write('<link rel="stylesheet" type="text/css" href="//share.lrcontent.com/prod/v2/css/os-share-widget-style.css"/>');
}
